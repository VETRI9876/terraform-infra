def lambda_handler(event, context):
    print("Alarm triggered!")
    return {
        "statusCode": 200,
        "body": "Alarm response handled successfully."
    }
